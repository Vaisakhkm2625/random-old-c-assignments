int getDiscountPercentage(float);

