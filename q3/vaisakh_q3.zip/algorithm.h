int searchInArrayOfElements(int value,int arr[], int n);
void sortArrayOfElements(int arr[], int n);
